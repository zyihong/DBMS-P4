#ifndef _CONSTANTS_HPP_
#define _CONSTANTS_HPP_

const unsigned int TUPLE_SIZE = 32;
const unsigned int PAGE_SIZE = 64;
const unsigned int MEM_BUFFER_SIZE = 256;

#endif